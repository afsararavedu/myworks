import RecruitDefaultLayout from './RecruitDefaultLayout';

export default RecruitDefaultLayout;
