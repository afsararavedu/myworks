import AdminDefaultLayout from './AdminDefaultLayout';

export default AdminDefaultLayout;
