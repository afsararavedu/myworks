
import Navs from './Navs';
import Paginations from './Paginations';
import Switches from './Switches';
import Tables from './Tables';
import Tabs from './Tabs';


export {
   Navs,  Switches, Tables, Tabs, Paginations
};

