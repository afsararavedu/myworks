import UserDetails from './UserDetails';
import Typography from './Typography';
import UserRegistration from './UserRegistration';

export {
  UserDetails, Typography, UserRegistration,
};