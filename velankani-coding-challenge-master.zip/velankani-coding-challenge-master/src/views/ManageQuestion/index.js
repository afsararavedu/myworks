import Paginations from './AddQuestion';
import SubjectiveQues from './SubjectiveQues';
import Tabs from './Tabs';
import ObjectiveQues from './ObjectiveQues';
import CreateQuestion from './CreateQuestion';
import Questions from './QuestionsList';

export {
  Paginations, SubjectiveQues, Tabs, ObjectiveQues,CreateQuestion,Questions
};