package com.vcti.ct.apiNamingServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiNamingServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
