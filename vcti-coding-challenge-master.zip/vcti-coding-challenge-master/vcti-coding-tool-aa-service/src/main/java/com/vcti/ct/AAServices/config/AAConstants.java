package com.vcti.ct.AAServices.config;

public interface AAConstants {
	static enum RoleEnum {
		SUPERADMIN, ADMIN, RECRUITMENT, CANDIDATE, INTERVIEWER, GUEST, TEST
	};
	static enum questionTypeEnum {
		OBJECTIVE,SUBJECTIVE
	};
}
