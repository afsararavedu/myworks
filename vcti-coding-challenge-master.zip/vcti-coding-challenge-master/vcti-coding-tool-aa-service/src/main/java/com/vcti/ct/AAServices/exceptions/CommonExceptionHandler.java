package com.vcti.ct.AAServices.exceptions;

import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @author sandeepkumar.yadav
 *
 */
@RestControllerAdvice
public class CommonExceptionHandler {

}
