package com.vcti.ct.AAServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AaServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
