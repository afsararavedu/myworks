package com.vcti.ct.CCTServices.repository;

import org.springframework.data.repository.CrudRepository;

import com.vcti.ct.CCTServices.model.SubjQuestion;

public interface SubjQuestionRepository extends CrudRepository<SubjQuestion, String> {
}