package com.vcti.ct.CCTServices.config;

public interface CCTConstants {
	static enum questionTypeEnum {
		OBJECTIVE, SUBJECTIVE
	};

	static enum status {
		SUCCESS, FAIL
	};
}
