package com.vcti.ct.CCTServices.repository;

import org.springframework.data.repository.CrudRepository;

import com.vcti.ct.CCTServices.model.ObjQuestion;

public interface ObjQuestionRepository extends CrudRepository<ObjQuestion, String> {
}