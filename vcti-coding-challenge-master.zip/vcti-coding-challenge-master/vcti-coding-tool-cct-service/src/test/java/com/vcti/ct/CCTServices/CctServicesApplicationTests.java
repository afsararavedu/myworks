package com.vcti.ct.CCTServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CctServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
