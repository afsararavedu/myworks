package com.vcti.ct.SRVServices.model;

public interface QuestionSchedView {
	String getQid();
}
